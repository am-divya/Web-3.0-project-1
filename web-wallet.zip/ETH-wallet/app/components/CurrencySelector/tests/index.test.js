// import React from 'react';
// import { shallow } from 'enzyme';

// import CurrencySelector from '../index';

describe('<CurrencySelector />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
