// import React from 'react';
// import { shallow } from 'enzyme';

// import LockButton from '../index';

describe('<LockButton />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
