// import React from 'react';
// import { shallow } from 'enzyme';

// import AddressTableFooterErrors from '../index';

describe('<AddressTableFooterErrors />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
