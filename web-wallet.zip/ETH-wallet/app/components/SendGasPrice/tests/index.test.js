// import React from 'react';
// import { shallow } from 'enzyme';

// import SendGasPrice from '../index';

describe('<SendGasPrice />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
