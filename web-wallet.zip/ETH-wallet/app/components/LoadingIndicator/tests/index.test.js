// import React from 'react';
// import { shallow } from 'enzyme';

// import LoadingIndicator from '../index';

describe('<LoadingIndicator />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
