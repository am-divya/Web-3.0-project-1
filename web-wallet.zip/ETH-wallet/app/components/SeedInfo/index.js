/**
*
* SeedInfo
*
*/

import React from 'react';
// import styled from 'styled-components';

class SeedInfo extends React.PureComponent { // eslint-disable-line react/prefer-stateless-function
  render() {
    return (
      <div>
        msg
      </div>
    );
  }
}

SeedInfo.propTypes = {

};

export default SeedInfo;
