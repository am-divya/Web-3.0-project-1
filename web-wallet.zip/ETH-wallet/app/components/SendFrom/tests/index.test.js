// import React from 'react';
// import { shallow } from 'enzyme';

// import SendFrom from '../index';

describe('<SendFrom />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
