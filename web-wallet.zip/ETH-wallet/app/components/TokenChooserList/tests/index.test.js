// import React from 'react';
// import { shallow } from 'enzyme';

// import TokenChooserList from '../index';

describe('<TokenChooserList />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
