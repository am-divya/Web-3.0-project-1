/*
 *
 * TokenChooser constants
 *
 */

export const TOGGLE_TOKEN = 'eth-Hot-Wallet/TokenChooser/TOGGLE_TOKEN';

export const CONFIRM_UPDATE_TOKEN_INFO = 'eth-Hot-Wallet/TokenChooser/CONFIRM_UPDATE_TOKEN_INFO';
