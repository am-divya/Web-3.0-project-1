// import React from 'react';
// import { shallow } from 'enzyme';

// import { TokenChooser } from '../index';

describe('<TokenChooser />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
