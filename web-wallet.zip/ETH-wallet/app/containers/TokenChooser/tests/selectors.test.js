// import { fromJS } from 'immutable';
// import { makeSelectTokenChooserDomain } from '../selectors';

// const selector = makeSelectTokenChooserDomain();

describe('makeSelectTokenChooserDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
