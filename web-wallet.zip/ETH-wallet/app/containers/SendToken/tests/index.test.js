// import React from 'react';
// import { shallow } from 'enzyme';

// import { SendToken } from '../index';

describe('<SendToken />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
