/*
 * SendToken Messages
 *
 * This contains all the text for the SendToken component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.SendToken.header',
    defaultMessage: 'This is SendToken container !',
  },
});
