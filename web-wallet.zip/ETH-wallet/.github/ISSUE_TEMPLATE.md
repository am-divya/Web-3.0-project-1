# Eth-Hot-Wallet

Please direct redux-saga related questions to stack overflow:
http://stackoverflow.com/questions/tagged/redux-saga
=======

## Issue Type

- [ ] Bug
- [ ] Feature

## Description

(Add images if possible)

## Steps to reproduce

(Add link to a demo on https://jsfiddle.net or similar if possible)


# Versions

- ETH-Hot-Wallet (see `package.json`):
- Node/NPM:
- Browser:
